import pytest
import numpy as np
from number_tools.statistics import mean, median, mode, variance, standard_deviation

@pytest.fixture
def sample_data():
    return [1, 2, 2, 3, 4, 4, 5]

def test_mean(sample_data):
    assert mean(sample_data) == 3
    assert mean([1, 2, 3]) == 2
    assert mean([0, 0, 0]) == 0
    
    with pytest.raises(ValueError):
        mean([])

def test_median(sample_data):
    assert median(sample_data) == 3
    assert median([1, 2, 3, 4]) == 2.5
    assert median([1]) == 1
    
    with pytest.raises(ValueError):
        median([])

def test_mode(sample_data):
    assert mode(sample_data) == [2, 4]
    assert mode([1, 1, 1, 2, 3]) == [1]
    assert mode([1, 2, 3]) == [1, 2, 3]
    
    with pytest.raises(ValueError):
        mode([])

def test_variance(sample_data):
    assert abs(variance(sample_data) - 1.9183) < 0.0001
    assert variance([1, 1, 1]) == 0
    
    with pytest.raises(ValueError):
        variance([])

def test_standard_deviation(sample_data):
    assert abs(standard_deviation(sample_data) - 1.3851) < 0.0001
    assert standard_deviation([1, 1, 1]) == 0
    
    with pytest.raises(ValueError):
        standard_deviation([])