import pytest
from number_tools.series import fibonacci, arithmetic_sequence, geometric_sequence, harmonic_sequence

def test_fibonacci():
    assert fibonacci(0) == []
    assert fibonacci(1) == [0]
    assert fibonacci(5) == [0, 1, 1, 2, 3]
    assert fibonacci(8) == [0, 1, 1, 2, 3, 5, 8, 13]
    
    with pytest.raises(ValueError):
        fibonacci(-1)

def test_arithmetic_sequence():
    assert arithmetic_sequence(1, 2, 5) == [1, 3, 5, 7, 9]
    assert arithmetic_sequence(0, 3, 4) == [0, 3, 6, 9]
    assert arithmetic_sequence(5, -1, 3) == [5, 4, 3]
    
    with pytest.raises(ValueError):
        arithmetic_sequence(1, 1, -1)

def test_geometric_sequence():
    assert geometric_sequence(1, 2, 4) == [1, 2, 4, 8]
    assert geometric_sequence(2, 3, 3) == [2, 6, 18]
    assert geometric_sequence(1, 0.5, 3) == [1, 0.5, 0.25]
    
    with pytest.raises(ValueError):
        geometric_sequence(1, 0, 5)

def test_harmonic_sequence():
    result = harmonic_sequence(1, 4)
    assert len(result) == 4
    assert result[0] == 1
    assert abs(result[1] - 0.5) < 0.0001
    
    with pytest.raises(ValueError):
        harmonic_sequence(0, 3)
    with pytest.raises(ValueError):
        harmonic_sequence(1, -1)