import pytest
import numpy as np
from number_tools.scaling import normalize, standardize, min_max_scale, robust_scale

@pytest.fixture
def sample_data():
    return np.array([1, 2, 3, 4, 5])

def test_normalize(sample_data):
    result = normalize(sample_data)
    assert len(result) == len(sample_data)
    assert np.isclose(np.mean(result), 0)
    assert np.isclose(np.std(result), 1)

def test_standardize(sample_data):
    result = standardize(sample_data)
    assert len(result) == len(sample_data)
    assert np.min(result) >= -1
    assert np.max(result) <= 1

def test_min_max_scale(sample_data):
    result = min_max_scale(sample_data)
    assert len(result) == len(sample_data)
    assert np.min(result) == 0
    assert np.max(result) == 1

def test_robust_scale(sample_data):
    result = robust_scale(sample_data)
    assert len(result) == len(sample_data)
    
def test_empty_input():
    empty_data = np.array([])
    with pytest.raises(ValueError):
        normalize(empty_data)
    with pytest.raises(ValueError):
        standardize(empty_data)
    with pytest.raises(ValueError):
        min_max_scale(empty_data)
    with pytest.raises(ValueError):
        robust_scale(empty_data)