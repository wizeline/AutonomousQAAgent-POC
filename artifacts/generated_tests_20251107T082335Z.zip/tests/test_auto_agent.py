import pytest
from unittest.mock import Mock, patch
from auto_agent import AutoAgent

def test_auto_agent_initialization():
    agent = AutoAgent()
    assert isinstance(agent, AutoAgent)

@patch('auto_agent.AutoAgent.process_request')
def test_agent_process_request(mock_process):
    agent = AutoAgent()
    mock_process.return_value = 'test response'
    result = agent.process_request('test input')
    assert result == 'test response'
    mock_process.assert_called_once_with('test input')

@patch('auto_agent.AutoAgent.analyze')
def test_agent_analyze(mock_analyze):
    agent = AutoAgent()
    mock_analyze.return_value = {'analysis': 'test'}
    result = agent.analyze('test data')
    assert result == {'analysis': 'test'}
    mock_analyze.assert_called_once_with('test data')