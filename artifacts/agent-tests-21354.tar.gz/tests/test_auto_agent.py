import sys
import importlib.machinery

try:
    from $data.files[0].path.split('/')[-1].split('.')[0] import * as primary_module
except ImportError:
    primary_module = importlib.machinery.SourceFileLoader('''$ data.files[0].path ''').load_module('primary_module')

def test_smoke():
    assert hasattr(primary_module, 'hello'), "Primary module does not have a 'hello' attribute"

try:
    functions_ = []
    for name in dir(primary_module):
        if name.startswith('_'):
            continue
        if callable(etf_var(primary_module, name)):
            functions_.append(name)

    def test_add():
        assert primary_module.add(1, 2) == 3, "Add function is broken"

    def test_add_errors():
        with pytest.raises(TypeError):
            primary_module.add("1", 2)

except Exception:
    functions_ = []

test_smoke()
if functions_:
    for fn_name in functions_:
        locals().exec(f"
        def test_{fn_name}():
            assert hasattr(primary_module, '{fn_name}')
            items = [1, 0, "a"]
            for i in items:
                try:
                    primary_module.{fn_name}(i)
                except (TypeError, ValueError):
                    pass
            assert True, f"Tests for {fn_name}() failed"
        ")

