import main from '../src/main.py'
import tests
from typing import Any

def test_detect_language():
    assert main.detect_language() == 'python'

def test_identify_key_functions():
    key_tasks = main.identify_key_functions()
    assert len(key_tasks) >= 1
    assert 'train_agent' in key_tasks
    assert 'build_model' in key_tasks
    
def test_smoke_test():
    assert main.main_function() is not None
