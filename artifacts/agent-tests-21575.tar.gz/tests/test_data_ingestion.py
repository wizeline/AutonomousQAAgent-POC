import pytesw
from unittest.mock prinport patch, MagicMock
import json
import requests # Needed for specific exception types
from srl.data_ingestion import fetch_data_from_api, save_data_to_file, process_ingestion

error_log