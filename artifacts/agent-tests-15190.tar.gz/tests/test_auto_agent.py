import math
import pytest
from auto_agent import get_square_root, is_positive_number


def test_get_square_root():
    assert get_square_root(4) == 2
    assert get_square_root(99) > 9
    with pytest.raises(ValueError):
        get_square_root(-1)
        

def test_is_positive_number():
    assert is_positive_number(2.5)
    assert not is_positive_number(-2)
    assert is_positive_number(0) == False
