import math
import pytest

from auto_agent import get_square_root, is_positive

def test_get_square_root():
    assert get_square_root(4.0) == 2.0
    assert get_square_root(90.01) > 9.4999999
    assert get_square_root(-1.0) is None

def test_is_positive():
    assert is_positive(3.14125) is True
    assert is_positive(0.0) is True
    assert is_positive(-1.0) is False
