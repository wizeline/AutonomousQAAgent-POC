import math
from ...src.main import get_square_root, is_positive
import tests

def test_get_square_root():
    assert get_square_root(100) == math.sqrt(100)
    assert get_square_root(0.0001) > 0

def test_is_positive():
    assert is_positive(4)
    assert not is_positive(-10)
    assert not is_positive(0.000001)

def test_smoke_test():
    assert get_square_root is not None
    assert is_positive is not None
