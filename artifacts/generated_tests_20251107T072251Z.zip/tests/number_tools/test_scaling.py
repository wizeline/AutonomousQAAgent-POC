import pytest
from number_tools.scaling import scale_linear, normalize

def test_scale_linear():
    assert scale_linear(5, 0, 10, 0, 1) == 0.5
    assert scale_linear(0, 0, 10, 0, 100) == 0
    assert scale_linear(10, 0, 10, 0, 100) == 100

def test_normalize():
    data = [0, 5, 10]
    result = normalize(data)
    assert result == [0.0, 0.5, 1.0]
    
    data = [1, 1, 1]
    result = normalize(data)
    assert all(x == 0 for x in result)

def test_normalize_empty():
    with pytest.raises(ValueError):
        normalize([])