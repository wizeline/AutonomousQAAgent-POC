import pytest
from number_tools.statistics import mean, median, mode, standard_deviation

def test_mean():
    assert mean([1, 2, 3]) == 2
    assert mean([0, 0, 0]) == 0
    assert mean([-1, 0, 1]) == 0
    with pytest.raises(ValueError):
        mean([])

def test_median():
    assert median([1, 2, 3]) == 2
    assert median([1, 2, 3, 4]) == 2.5
    assert median([3, 1, 2]) == 2
    with pytest.raises(ValueError):
        median([])

def test_mode():
    assert mode([1, 1, 2, 3]) == 1
    assert mode([1, 2, 2, 3, 3]) == 2
    assert mode([1, 1, 2, 2]) == 1
    with pytest.raises(ValueError):
        mode([])

def test_standard_deviation():
    assert standard_deviation([2, 4, 4, 4, 5, 5, 7, 9]) == pytest.approx(2.0, rel=1e-2)
    assert standard_deviation([1, 1, 1]) == 0
    assert standard_deviation([-2, 0, 2]) == pytest.approx(2.0, rel=1e-2)
    with pytest.raises(ValueError):
        standard_deviation([])