import math
import pytest

from ..main import get_square_root, is_positive_number

def test_get_square_root():
    assert get_square_root(9.0) == 3.0
    assert get_square_root(100.0) == 10.0
    assert get_square_root(-1.0) != 1.0


def test_is_positive_number():
    assert is_positive_number(4.0)
    assert not is_positive_number(-2.0)
    assert is_positive_number(0.0)


def test_main_module_loads()