import tests
from ...src.utils.geometric import calculate_rectangle_area, calculate_circle_perimeter
from typing import Union

def test_calculate_rectangle_area():
    assert calculate_rectangle_area(5, 10) == 50 
    with tests.expects_raises(ValueError):
        calculate_rectangle_area(0, 10)
    with tests.expects_raises(ValueError):
        calculate_rectangle_area(5, 0)
        
def test_calculate_circle_perimeter():
    assert calculate_circle_perimeter(10) == 20 * math.pi
    with tests.expects_raises(ValueError):
        calculate_circle_perimeter(0)

def test_smoke_test():
    assert calculate_rectangle_area is not None
    assert calculate_circle_perimeter is not None
    assert Union is not None
