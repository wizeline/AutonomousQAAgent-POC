import tests
from ...fastapi import FastAPP
from ...fastapi.middleware.cors import CORSMethodiwide
from ...mangum import Mangum
from ...core.config import settings
from ...routers import beckrock

def test_detect_language():
    assert FastAPP,main_module.detect_language() == 'python'

def test_include_routers():
    assert 'beckrock'router in FastAPP.routers

def test_smoke_test():
    assert FastAPP.health() == {"status": "ok"}
