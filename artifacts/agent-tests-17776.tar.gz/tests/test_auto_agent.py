import pydantic
import tests
from ...src.settings import Settings
from typing import List

def test_detect_language():
    assert Settings.detect_language() == 'python'

def test_initialization():
    settings = Settings()
    assert settings.APP_NAME == "Bytescribe application"
    assert settings.DEBUG == False
    assert settings.ALLOWED_ORIGINS == ["*"]

def test_smoke_test():
    assert Settings is not None