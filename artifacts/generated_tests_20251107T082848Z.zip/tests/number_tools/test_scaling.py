import pytest
import numpy as np
from number_tools.scaling import normalize, standardize, min_max_scale, rescale

def test_normalize():
    data = [1, 2, 3, 4, 5]
    result = normalize(data)
    assert len(result) == len(data)
    assert np.isclose(np.mean(result), 0)
    assert np.isclose(np.std(result), 1)

def test_standardize():
    data = [10, 20, 30, 40, 50]
    result = standardize(data)
    assert len(result) == len(data)
    assert min(result) >= -1
    assert max(result) <= 1

def test_min_max_scale():
    data = [1, 2, 3, 4, 5]
    result = min_max_scale(data)
    assert len(result) == len(data)
    assert min(result) == 0
    assert max(result) == 1

def test_rescale():
    data = [1, 2, 3, 4, 5]
    new_min, new_max = 0, 10
    result = rescale(data, new_min, new_max)
    assert len(result) == len(data)
    assert min(result) == new_min
    assert max(result) == new_max

def test_empty_input():
    with pytest.raises(ValueError):
        normalize([])
    with pytest.raises(ValueError):
        standardize([])
    with pytest.raises(ValueError):
        min_max_scale([])
    with pytest.raises(ValueError):
        rescale([], 0, 1)