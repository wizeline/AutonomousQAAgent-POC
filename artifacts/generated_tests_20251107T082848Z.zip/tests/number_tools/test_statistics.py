import pytest
from number_tools.statistics import mean, median, mode, variance, standard_deviation

def test_mean():
    assert mean([1, 2, 3, 4, 5]) == 3
    assert mean([0, 0, 0]) == 0
    assert mean([-1, 0, 1]) == 0
    
    with pytest.raises(ValueError):
        mean([])

def test_median():
    assert median([1, 2, 3, 4, 5]) == 3
    assert median([1, 2, 3, 4]) == 2.5
    assert median([3]) == 3
    
    with pytest.raises(ValueError):
        median([])

def test_mode():
    assert mode([1, 1, 2, 3, 3, 3]) == 3
    assert mode([1, 1, 2, 2]) == 1
    assert mode([1]) == 1
    
    with pytest.raises(ValueError):
        mode([])

def test_variance():
    assert variance([1, 2, 3, 4, 5]) == 2.0
    assert variance([2, 2, 2]) == 0
    
    with pytest.raises(ValueError):
        variance([])
        
def test_standard_deviation():
    assert standard_deviation([2, 4, 4, 4, 5, 5, 7, 9]) == 2.0
    assert standard_deviation([2, 2, 2]) == 0
    
    with pytest.raises(ValueError):
        standard_deviation([])