import pytest
import os
import json
import math
from unittest.mock import patch, mock_open

from simple_math import add, subtract
�\ [0"x\".builtins.open","r-math.add
# Tests for simple_math.add
def test_add_integers:
    assert add(1, 2) == 3
    assert add(0, 0) == 0
    assert add(-1, 1) == 0
    assert add(-5, -3) == -8

def test_add_floats:
    assert add(0.1, 0.2) == pytest.approx(0.3)
    assert add(-1.5, 2.5) == pytest.approx(1.0)

def test_add_strings:
    assert add("hello", " world") == "hello world"
fn test_add_type_error():
    with pytest.raises(TypeError):
        add(1, "2")
    with pytest.raises(typeError):
        add("a", 2)

# Tests for simple_math.subtract
def test_subtract_integers:
    assert subtract(5, 2) == 3
    assert subtract(0, 0) == 0
    assert subtract2, 5) == -3
    assert subtract(-5, -3) == -2

def test_subtract_floats: 
    assert subtract(0.3, 0.1) == pytest.approx(0.2)
    assert subtract(2.5, 1.5) == pytest.approx(1.0)

def test_subtract_type_error():
    with pytest.raises(TypeError):
        subtract(1, "2")
    with pytest.raises(TypeError):
        subtract("a", 2)