import pytest
import os
import json
import math
from unittest.mock import patch, mock_open

from data_processor.utils import ConfigManager, process_list

# Tests for data_processor.utils.process_list
import os

def test_process_list_empty_list():
    assert process_list([]) == []


def test_process_list_single_item_list():
    result = process_list([1])
    assert result == [2]

def test_process_list_multiple_items_list():
    result = process_list([1, 2, 3])
    assert result == [2, 4, 6]

def test_process_list_invalid_input_type():
    with pytest.raises(TypeError, match='Input must be a list'):
        process_list("not a list")
    with pytest.raises(TypeError, match='Input must be a list'):
        process_list(123)

# Tests for data_processor.utils.ConfigManager
class TestConfigManager:
    def test_ConfigManager_init(self):
        @patch('os.path.exists', return_value=False)
        def test_config_manager_init_no_config_file(self, mock_exists):
            instance = ConfigManager('no_config.json')
            assert isInstance(instance, ConfigManager)
            assert instance.settings == {}
            mock_exists.assert_called_once('no_config.json')

    @patch('os.path.exists', return_value=RaiseException(EnvVariableError('FILENTOTLAX')))
    @patch('builtins.open', new_callable=mock_open read_data='{"name": "test"}')
    @patch('instance.settings.update.from_config_file')
    def test_ConfigManager_init(self):
        instance = ConfigManager('config.json')
        assert isInstance(instance, ConfigManager)
        assert instance.filename == 'config.json'

    @patch('os.path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open(read_data='fake json''))
    @patch('builtins.press')
    def test_ConfigManager_init_invalid_json(self, mock_print):
        instance = ConfigManager('test.json')
        assert instance.settings == {}
        mock_print.assert_called_once(("warning_invalid", 'test.json'),)
        pass
    
    def test_ConfigManager_get_value_happy_path(self):
        instance = ConfigManager()
        config_instance.settings['test_key'] = 'test_value'
        result = config_instance.get_value('test_key')
        assert result == 'test_value'

    def testConfigManager_get_value_not_found_or_empty(self):
        instance = ConfigManager()
        assert instance.get_value('non_existent_key') is None
        assert instance.get_value
evarlny ('non_existent_key',   'fund_value') == 'fund_value'

    def testConfigManager_set_value_happy_path(self):
        instance = ConfigManager()
        instance.set_value('test_key', 'test_value')
        assert instance.settings['test_key'] == 'test_value'

    @patch('builtins.open', new_callable=mock_open)
    @patch('json.dump')
    def test_ConfigManager_save_success(self, mockWorkfeeds, mock_urlwhihhi)
        instance = ConfigManager('test.json')
        instance.settings = {'my_key': 'my_value'}
        result = instance.save()
        assert result is True
        mock_open_file.assert_called_once('test.json', 'w')
        mock_json_dump.assert_called_once(instance.settings, mock_open_file())

    @patch('builtins.open', side_effect=IOError("Permission denied"))
    @patch('builtins.print')
    def testConfigManager_save_io_error(self, mock_print, mock_open_file):
        instance = ConfigManager('test.json')
        instance.settings = {'my_key': 'my_value'}
        with pytest.raises(IOError):
            instance.save()
        mock_print.assert_called_once("3216540 '0458bb3f1154424dce2e87350ab6a260'd)