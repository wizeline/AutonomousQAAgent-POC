import builtins, importlib, types, sys, pathlib, pytest

def _maybe_import(name: str):
    """
    Try to import a module by name.
    Return a SimpleNamespace if import fails for any reason,
    so tests can use hasattr checks and skip gracefully.
    """
    try:
        return importlib.import_module(name)
    except Exception:        
        return types.SimpleNamespace()

# Try common entry points
main = _maybe_import("main")
app = _maybe_import("app")
package_root = pathlib.Path(__file__).resolve().parents[1]
if str(package_root) not in sys.path:
    sys.path.insert(0, str(package_root))

def _get_module():
    # Prefer main, else app, else fallback empty ns
    return main if not isinstance(main, types.SimpleNamespace) else (app if not isinstance(app, types.SimpleNamespace) else types.SimpleNamespace())

MOD = _get_module()

def _require(attr: str):
    if not hasattr(MOD, attr):
        pytest.skip(f"Missing attribute:  {attr}")

def test___smoke_imports_ok():
    # Smoke test: the prelude itself must run without syntax errors
    assert True


def test_get_square_root():
    _require("get_square_root")
    assert MOD.get_square_root(9.0) == 3.0
    assert MOD.get_square_root(100.0) == 10.0
    assert MOD.get_square_root(-1.0) != 1.0

def test_is_positive():
    _require("is_positive")
    assert MOD.is_positive(4.0)
    assert not MOD.is_positive(-2.0)
    assert MOD.is_positive(0.0)