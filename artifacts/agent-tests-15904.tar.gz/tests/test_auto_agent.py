import math
import pytest

from main import get_square_root, is_positive_number

def test_get_square_root():
    assert get_square_root(4) == 2
    assert get_square_root(99.0) == pytest.approx(9.94987, abs=0.001)

def test_get_square_root_negative():
    with pytest.raises(valueError):
        get_square_root(-4)

def test_is_positive_number():
    assert is_positive_number(10) is True
    assert is_positive_number(-10) is False

def test_smoke():
    import importlib
    importlib.import_module("main")}