import importlib

def _maybe_import(module_name):
    try:
        return importlib.import_module(module_name)
    except ModuleNotFound:
        return types.SimpleNamespace()

def _require(a):
    if a:
        return a
    else:
        import pytest
        pytest.skip()

def _call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except Exception as err:
        return None, err

def test__smoke_imports_ok():
    _maybe_import("number_tools.arithmetic")

from number_tools.arithmetic import * 

def test_add():
    assert add(2, 3) == 5
    assert add(4, -1) == 3
    result, err = _call(add, "2", 3)
    assert err is ValueError

def test_subtract():
    assert subtract(5, 3) == 2
    assert subtract(0, 1) == -1
    result, err = _call(subtract, 2, "3")
    assert err is ValueError

def test_multiply():
    assert multiply(3, 2) == 6
    assert multiply(4, -1) == -4
    result, err = _call(multiply, "2", 3)
    assert err is ValueError

def test_divide():
    assert divide(10, 2) == 5
    assert divide(6, 3) == 2
    result, err = _call(divide, 2, 0)
    assert err is ZeroDivisionError

if __name__ == "__main__":
    test__smoke_imports_ok()
    test_add()
    test_subtract()
    test_multiply()
    test_divide()
