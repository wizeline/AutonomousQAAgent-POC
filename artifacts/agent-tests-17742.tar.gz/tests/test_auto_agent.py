import main from '../src/main.py'
import tests

def test_detect_language():
    assert main.detect_language() == 'python'

def test_identify_key_constants():
    constants = {
        "BEDROCK_MODEL_AWS_TITANT": "amazon.titan-text-express-v1", 
        "BEDROCK_MODEL_ANTHROPIC_CLAUDM35": "anthropic.claude-3-5-sonnet-20240620-v1:0"
    }
    assert main.IMPORTANT_CONSTANTS == constants

def test_smoke_test():
    assert main.main_function() is not None
