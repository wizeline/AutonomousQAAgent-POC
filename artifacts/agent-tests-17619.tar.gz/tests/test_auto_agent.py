import main from '../src/main.py'

import tests

\MAIN_CONSTANTS = {
    "BEDROCK_MODEL_AWS_TITANT": "amazon.titan-text-express-v1",
    "BEDROCK_MODEL_ANTHROPIC_CLAUDE35": "anthropic.claude-3-5-sonnet-20240620-v1:0"
}

def test_detect_language():
    assert main.detect_language() == 'python'

def test_identify_key_constants():
    assert MAIN_CONSTANTS == {
        "BEDROCK_MODEL_AWS_TITANT" : "amazon.titan-text-express-v1",
        "BEDROCK_MODERCL_ANTHROPIC_CLAUDE35" : "anthropic.claude-3-5-sonnet-20240620-v1:0"
    }

def test_smoke_test():
    assert main.main_function() is not None