import pytest
from number_tools.statistics import mean, median, mode, variance

def test_mean():
    assert mean([1, 2, 3]) == 2
    assert mean([0, 0, 0]) == 0
    with pytest.raises(ValueError):
        mean([])

def test_median():
    assert median([1, 2, 3]) == 2
    assert median([1, 2, 3, 4]) == 2.5
    with pytest.raises(ValueError):
        median([])

def test_mode():
    assert mode([1, 1, 2, 3]) == 1
    assert mode([1, 2, 2, 3, 3]) == 2
    with pytest.raises(ValueError):
        mode([])

def test_variance():
    assert variance([1, 2, 3]) == 0.6666666666666666
    assert variance([2, 2, 2]) == 0
    with pytest.raises(ValueError):
        variance([])