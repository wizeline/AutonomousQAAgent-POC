import pytest
from number_tools.series import fibonacci, arithmetic_sequence, geometric_sequence

def test_fibonacci():
    assert fibonacci(0) == []
    assert fibonacci(1) == [0]
    assert fibonacci(5) == [0, 1, 1, 2, 3]
    assert fibonacci(8) == [0, 1, 1, 2, 3, 5, 8, 13]

def test_arithmetic_sequence():
    assert arithmetic_sequence(1, 2, 5) == [1, 3, 5, 7, 9]
    assert arithmetic_sequence(0, 3, 4) == [0, 3, 6, 9]
    assert arithmetic_sequence(5, -1, 3) == [5, 4, 3]

def test_geometric_sequence():
    assert geometric_sequence(1, 2, 4) == [1, 2, 4, 8]
    assert geometric_sequence(2, 3, 3) == [2, 6, 18]
    with pytest.raises(ValueError):
        geometric_sequence(1, 0, 5)