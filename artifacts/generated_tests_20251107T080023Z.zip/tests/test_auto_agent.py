import pytest
from auto_agent import AutoAgent

def test_auto_agent_initialization():
    agent = AutoAgent()
    assert isinstance(agent, AutoAgent)

def test_auto_agent_attributes():
    agent = AutoAgent()
    assert hasattr(agent, 'name')
    assert hasattr(agent, 'state')